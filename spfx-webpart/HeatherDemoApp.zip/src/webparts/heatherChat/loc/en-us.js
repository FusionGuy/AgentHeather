define([], function() {
  return {
    "PropertyPaneDescription": "Configure the Heather Chat web part",
    "BasicGroupName": "Connection Settings",
    "ApiBaseUrlFieldLabel": "API Base URL",
    "AppLocalEnvironmentSharePoint": "The app is running on your local environment as SharePoint web part",
    "AppLocalEnvironmentTeams": "The app is running on your local environment as Microsoft Teams app",
    "AppSharePointEnvironment": "The app is running on SharePoint page",
    "AppTeamsTabEnvironment": "The app is running in Microsoft Teams"
  }
});
