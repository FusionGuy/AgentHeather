import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IHeatherChatProps {
    apiBaseUrl: string;
    context: WebPartContext;
}
interface IChatMessage {
    role: 'user' | 'assistant';
    content: string;
}
interface IHeatherChatState {
    messages: IChatMessage[];
    inputValue: string;
    isLoading: boolean;
    error: string | null;
}
export declare class HeatherChat extends React.Component<IHeatherChatProps, IHeatherChatState> {
    private chatEndRef;
    constructor(props: IHeatherChatProps);
    componentDidUpdate(_prevProps: IHeatherChatProps, prevState: IHeatherChatState): void;
    private _scrollToBottom;
    private _handleInputChange;
    private _handleKeyDown;
    private _sendMessage;
    private _clearChat;
    /**
     * Convert basic markdown to HTML for rendering assistant responses.
     * Handles bold, italic, line breaks, bullet lists, and numbered lists.
     */
    private _renderMarkdown;
    private _renderMessage;
    render(): React.ReactElement<IHeatherChatProps>;
}
export {};
//# sourceMappingURL=HeatherChat.d.ts.map