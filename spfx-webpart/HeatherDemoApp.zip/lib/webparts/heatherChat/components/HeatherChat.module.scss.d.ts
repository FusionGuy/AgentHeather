declare const styles: {
    heatherChat: string;
    header: string;
    headerAvatar: string;
    headerTitle: string;
    headerSubtitle: string;
    errorBar: string;
    chatBody: string;
    emptyState: string;
    emptyAvatar: string;
    emptyText: string;
    emptySubtext: string;
    messageRow: string;
    userRow: string;
    assistantRow: string;
    avatar: string;
    messageBubble: string;
    userBubble: string;
    assistantBubble: string;
    messageLabel: string;
    assistantLabel: string;
    labelIcon: string;
    messageText: string;
    inputArea: string;
    inputField: string;
    sendButton: string;
};
export default styles;
//# sourceMappingURL=HeatherChat.module.scss.d.ts.map